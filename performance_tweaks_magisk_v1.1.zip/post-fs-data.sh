#!/system/bin/sh
# Performance Tweaks Module - post-fs-data script
# By willygailo01@gmail.com

# This script runs during the post-fs-data stage

MODDIR=${0%/*}

# Wait until the system is properly booted
until [ "$(getprop sys.boot_completed)" = "1" ]; do
  sleep 1
done

# Log file
LOG_FILE="/data/local/tmp/performance_tweaks_log.txt"

# Clear the log file
echo "Performance Tweaks Log - $(date)" > $LOG_FILE

# Set higher process priority for this script
renice -n -10 $$

# Function to log actions
log_action() {
  echo "$(date +%H:%M:%S) - $1" >> $LOG_FILE
}

# Check Android version
ANDROID_VER=$(getprop ro.build.version.release)
ANDROID_SDK=$(getprop ro.build.version.sdk)

log_action "Detected Android version: $ANDROID_VER (SDK: $ANDROID_SDK)"

# Only run on Android 10+ (SDK 29+)
if [ "$ANDROID_SDK" -lt 29 ]; then
  log_action "Device running Android SDK $ANDROID_SDK, which is below Android 10 (SDK 29). Exiting."
  exit 0
fi

log_action "Device is running Android 10+ - proceeding with tweaks"

# Execute remaining script in the background to avoid boot delays
{
  # Apply basic tweaks
  log_action "Applying basic performance tweaks"
  
  # Set governor to performance if available
  for CPU in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    if [ -f "$CPU" ]; then
      echo "performance" > $CPU 2>/dev/null
      log_action "Set $(basename $(dirname $(dirname $CPU))) governor: $(cat $CPU 2>/dev/null)"
    fi
  done
  
  # Disable thermal throttling for better performance (with caution)
  THERMAL_PATH="/sys/class/thermal"
  if [ -d "$THERMAL_PATH" ]; then
    for ZONE in $THERMAL_PATH/thermal_zone*; do
      if [ -f "$ZONE/mode" ]; then
        echo "disabled" > $ZONE/mode 2>/dev/null
        log_action "Set thermal mode for $(basename $ZONE): $(cat $ZONE/mode 2>/dev/null)"
      fi
    done
  fi
  
  # VM tweaks for better performance
  echo "10" > /proc/sys/vm/swappiness 2>/dev/null
  echo "50" > /proc/sys/vm/vfs_cache_pressure 2>/dev/null
  echo "128" > /proc/sys/vm/dirty_background_ratio 2>/dev/null
  echo "256" > /proc/sys/vm/dirty_ratio 2>/dev/null
  log_action "Applied VM tweaks"
  
  # I/O scheduler tweaks
  for BLOCK in /sys/block/*/queue/scheduler; do
    if [ -f "$BLOCK" ]; then
      echo "cfq" > $BLOCK 2>/dev/null
      log_action "Set I/O scheduler for $(basename $(dirname $(dirname $BLOCK))): $(cat $BLOCK 2>/dev/null)"
    fi
  done
  
  # Apply additional tweaks based on Android version
  if [ "$ANDROID_SDK" -ge 30 ]; then
    # Android 11+ specific tweaks
    log_action "Applying Android 11+ specific tweaks"
    
    # Additional performance tweaks for Android 11+
    # Add any Android 11+ specific tweaks here
  fi
  
  log_action "Performance tweaks applied successfully"
} & 