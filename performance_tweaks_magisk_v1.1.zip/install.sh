#!/system/bin/sh
# Performance Tweaks Module
# By willygailo01@gmail.com

SKIPUNZIP=1
ASH_STANDALONE=1

# Magisk Module ID
MODID=performance_tweaks

# Define the directory paths
MODPATH=${0%/*}
TMPDIR=/dev/tmp
PERSISTDIR=/sbin/.magisk/mirror/persist

# Anti-bootloop protection variables
BOOTLOOPTIME=30
BOOTLOOPCONFIRMATIONS=3
BOOTCOUNTER="${PERSISTDIR}/${MODID}_bootcounter"
BOOTCONFIRMFILE="${PERSISTDIR}/${MODID}_bootconfirm"

# Print message with module details
ui_print() {
  echo "$1"
}

# Extract the module files
extract() {
  ui_print "- Extracting module files"
  unzip -o "$ZIPFILE" -d $MODPATH >&2
  
  # Set permissions
  set_permissions
}

# Set appropriate permissions for files
set_permissions() {
  ui_print "- Setting permissions"
  
  # Set execute permissions for scripts
  find $MODPATH -type f -name "*.sh" -exec chmod 755 {} \;
  
  # Set standard permissions for other files
  find $MODPATH -type f -not -name "*.sh" -exec chmod 644 {} \;
  
  # Set directory permissions
  find $MODPATH -type d -exec chmod 755 {} \;
  
  # Set specific permissions for the module scripts
  chmod 755 $MODPATH/service.sh
  chmod 755 $MODPATH/post-fs-data.sh
}

# Anti-bootloop protection check
check_bootloop() {
  # Create persist directory if it doesn't exist
  mkdir -p $PERSISTDIR
  
  if [ -f "$BOOTCONFIRMFILE" ]; then
    # Module has been confirmed as working, remove counter
    rm -f $BOOTCOUNTER
    return 0
  fi
  
  if [ ! -f "$BOOTCOUNTER" ]; then
    # First boot with module, create counter
    echo "1" > $BOOTCOUNTER
    # Schedule boot confirmation
    mkdir -p ${MODPATH}/service.d
    cat << 'EOF' > ${MODPATH}/service.d/bootcheck.sh
#!/system/bin/sh
MODID=performance_tweaks
PERSISTDIR=/sbin/.magisk/mirror/persist
BOOTLOOPTIME=30
BOOTCONFIRMFILE="${PERSISTDIR}/${MODID}_bootconfirm"
# Wait for BOOTLOOPTIME seconds
sleep $BOOTLOOPTIME
# Create confirmation file
touch $BOOTCONFIRMFILE
EOF
    chmod 755 ${MODPATH}/service.d/bootcheck.sh
    return 0
  else
    # Read boot counter
    COUNTER=$(cat $BOOTCOUNTER)
    COUNTER=$((COUNTER + 1))
    
    if [ $COUNTER -ge $BOOTLOOPCONFIRMATIONS ]; then
      # Too many reboots without confirmation, disable module
      ui_print "! Boot loop detected!"
      ui_print "! Disabling module for safety"
      touch $MODPATH/disable
      rm -f $BOOTCOUNTER
      return 1
    else
      # Update counter
      echo "$COUNTER" > $BOOTCOUNTER
      return 0
    fi
  fi
}

# Main installation function
install() {
  ui_print "**************************************"
  ui_print "*     Performance Tweaks Module      *"
  ui_print "*             Version 1.0            *"
  ui_print "*      Author: willygailo01@gmail.com  *"
  ui_print "**************************************"
  ui_print " "
  ui_print "- Compatible with Android 10+"
  ui_print "- Requires Magisk v29.0+"
  ui_print "- Anti-bootloop protection enabled"
  
  # Extract module files
  extract
  
  # Check for potential bootloop
  check_bootloop
  if [ $? -ne 0 ]; then
    ui_print "! Module disabled due to potential bootloop"
    ui_print "! Please contact the module author for support"
  else
    ui_print "- Module installed successfully"
    ui_print "- Reboot to activate"
  fi
}

# Start installation
install 