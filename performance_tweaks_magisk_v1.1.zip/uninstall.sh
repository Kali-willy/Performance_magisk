#!/system/bin/sh
# Performance Tweaks Module - uninstall script
# By willygailo01@gmail.com

# Remove any persistent files created by the module
PERSISTDIR=/sbin/.magisk/mirror/persist
MODID=performance_tweaks

# Remove bootloop protection files
rm -f ${PERSISTDIR}/${MODID}_bootcounter
rm -f ${PERSISTDIR}/${MODID}_bootconfirm

# Remove log files
rm -f /data/local/tmp/performance_tweaks_log.txt
rm -f /data/local/tmp/performance_tweaks_service_log.txt

# Reset CPU governors to default
for CPU in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
  if [ -f "$CPU" ]; then
    echo "schedutil" > $CPU 2>/dev/null || echo "interactive" > $CPU 2>/dev/null
  fi
done

# Reset thermal settings
THERMAL_PATH="/sys/class/thermal"
if [ -d "$THERMAL_PATH" ]; then
  for ZONE in $THERMAL_PATH/thermal_zone*; do
    if [ -f "$ZONE/mode" ]; then
      echo "enabled" > $ZONE/mode 2>/dev/null
    fi
  done
fi

# Reset VM settings to system defaults
echo "60" > /proc/sys/vm/swappiness 2>/dev/null
echo "100" > /proc/sys/vm/vfs_cache_pressure 2>/dev/null
echo "10" > /proc/sys/vm/dirty_background_ratio 2>/dev/null
echo "20" > /proc/sys/vm/dirty_ratio 2>/dev/null

# Reset animation scales
settings put global animator_duration_scale 1.0
settings put global transition_animation_scale 1.0
settings put global window_animation_scale 1.0

# Reset TCP congestion algorithm
if [ -f /proc/sys/net/ipv4/tcp_congestion_control ]; then
  echo "cubic" > /proc/sys/net/ipv4/tcp_congestion_control
fi

exit 0 