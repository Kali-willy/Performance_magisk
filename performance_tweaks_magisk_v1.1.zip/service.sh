#!/system/bin/sh
# Performance Tweaks Module - service script
# By willygailo01@gmail.com

# This script runs during late start service

MODDIR=${0%/*}

# Wait until the system is properly booted
until [ "$(getprop sys.boot_completed)" = "1" ]; do
  sleep 2
done

# Wait a bit more to ensure all services are up
sleep 30

# Log file
LOG_FILE="/data/local/tmp/performance_tweaks_service_log.txt"

# Clear the log file
echo "Performance Tweaks Service Log - $(date)" > $LOG_FILE

# Function to log actions
log_action() {
  echo "$(date +%H:%M:%S) - $1" >> $LOG_FILE
}

# Start applying tweaks
log_action "Starting performance tweaks service"

# Apply performance tweaks to running processes and services
{
  # Lower priority of background processes to give more resources to foreground apps
  for PID in $(ps -A | grep -v "PID" | awk '$3 > 10000' | awk '{print $2}'); do
    PNAME=$(cat /proc/$PID/cmdline 2>/dev/null)
    if [ -n "$PNAME" ] && [ -d "/proc/$PID" ]; then
      # Skip certain system processes
      if ! echo "$PNAME" | grep -qE "com.android.systemui|com.android.phone|system_server"; then
        renice -n 10 -p $PID >/dev/null 2>&1
        log_action "Lowered priority for PID $PID ($PNAME)"
      fi
    fi
  done
  
  # Adjust kernel settings for better performance
  # TCP congestion to improved algorithm
  if [ -f /proc/sys/net/ipv4/tcp_congestion_control ]; then
    echo "westwood" > /proc/sys/net/ipv4/tcp_congestion_control
    log_action "Set TCP congestion control to: $(cat /proc/sys/net/ipv4/tcp_congestion_control)"
  fi
  
  # Disable debugging and logging features to improve performance
  settings put global development_settings_enabled 0
  settings put global adb_enabled 0
  settings put global stay_on_while_plugged_in 0
  settings put global animator_duration_scale 0.5
  settings put global transition_animation_scale 0.5
  settings put global window_animation_scale 0.5
  log_action "Adjusted system settings for performance"
  
  # Apply app-specific tweaks
  for APP in com.google.android.youtube com.facebook.katana com.instagram.android com.whatsapp; do
    if pm list packages | grep -q $APP; then
      am set-inactive $APP true >/dev/null 2>&1
      log_action "Set $APP to inactive when not in use"
    fi
  done
  
  # Set CPU governor based on battery state
  BATTERY_LEVEL=$(dumpsys battery | grep level | awk '{print $2}')
  CHARGING_STATE=$(dumpsys battery | grep "powered" | grep -q "true" && echo "charging" || echo "discharging")
  
  if [ "$CHARGING_STATE" = "charging" ]; then
    # Use performance governor when charging
    for CPU in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
      if [ -f "$CPU" ]; then
        echo "performance" > $CPU 2>/dev/null
      fi
    done
    log_action "Device is charging, set CPU governor to performance"
  else
    # When on battery, use a balanced approach based on battery level
    if [ "$BATTERY_LEVEL" -gt 30 ]; then
      # Use interactive or schedutil for balanced performance
      for CPU in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
        if [ -f "$CPU" ]; then
          echo "schedutil" > $CPU 2>/dev/null || echo "interactive" > $CPU 2>/dev/null
        fi
      done
      log_action "Battery level $BATTERY_LEVEL%, set CPU governor to balanced"
    else
      # Use powersave for low battery
      for CPU in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
        if [ -f "$CPU" ]; then
          echo "powersave" > $CPU 2>/dev/null
        fi
      done
      log_action "Battery level low ($BATTERY_LEVEL%), set CPU governor to powersave"
    fi
  fi
  
  log_action "All performance tweaks applied successfully"
  
  # Create confirmation file to indicate successful boot
  PERSISTDIR=/sbin/.magisk/mirror/persist
  MODID=performance_tweaks
  mkdir -p $PERSISTDIR
  touch "${PERSISTDIR}/${MODID}_bootconfirm"
  log_action "Created boot confirmation file"
} & 